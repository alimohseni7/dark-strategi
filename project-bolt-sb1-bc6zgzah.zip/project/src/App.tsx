import React from 'react';
import { Sparkles, Scissors, ShoppingBag, Dumbbell, Heart, Smile } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-blue-50 to-indigo-50">
        <div className="container mx-auto px-4 py-20">
          <div className="max-w-4xl mx-auto text-center">
            <div className="mb-8 rounded-2xl overflow-hidden">
              <img 
                src="https://images.unsplash.com/photo-1621605815971-fbc98d665033?auto=format&fit=crop&w=2070&q=80"
                alt="Confident man in suit"
                className="w-full h-[400px] object-cover"
              />
            </div>
            <h1 className="text-5xl font-bold mb-6 bg-gradient-to-r from-blue-600 to-indigo-600 text-transparent bg-clip-text">
              How to Be So Attractive and Handsome
            </h1>
            <p className="text-xl text-gray-600 mb-8">
              Discover simple yet powerful ways to enhance your appearance and boost your confidence.
            </p>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-16">
        <div className="grid md:grid-cols-2 gap-12">
          {/* Skin Care Section */}
          <div className="bg-white rounded-2xl shadow-sm hover:shadow-md transition-shadow overflow-hidden">
            <img 
              src="https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=987&q=80"
              alt="Skincare products"
              className="w-full h-48 object-cover"
            />
            <div className="p-8">
              <div className="flex items-center mb-6">
                <Sparkles className="w-8 h-8 text-blue-500 mr-4" />
                <h2 className="text-2xl font-bold">Take Care of Your Skin</h2>
              </div>
              <ul className="space-y-4 text-gray-600">
                <li className="flex items-start">
                  <span className="w-2 h-2 mt-2 rounded-full bg-blue-500 mr-3"></span>
                  Wash your face twice daily with a gentle cleanser
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 mt-2 rounded-full bg-blue-500 mr-3"></span>
                  Use a moisturizer to keep your skin hydrated
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 mt-2 rounded-full bg-blue-500 mr-3"></span>
                  Apply sunscreen daily to prevent premature aging
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 mt-2 rounded-full bg-blue-500 mr-3"></span>
                  Drink plenty of water for clear, fresh skin
                </li>
              </ul>
            </div>
          </div>

          {/* Haircut Section */}
          <div className="bg-white rounded-2xl shadow-sm hover:shadow-md transition-shadow overflow-hidden">
            <img 
              src="https://images.unsplash.com/photo-1622286342621-4bd786c2447c?auto=format&fit=crop&w=2070&q=80"
              alt="Man getting haircut"
              className="w-full h-48 object-cover"
            />
            <div className="p-8">
              <div className="flex items-center mb-6">
                <Scissors className="w-8 h-8 text-blue-500 mr-4" />
                <h2 className="text-2xl font-bold">Maintain a Stylish Haircut</h2>
              </div>
              <ul className="space-y-4 text-gray-600">
                <li className="flex items-start">
                  <span className="w-2 h-2 mt-2 rounded-full bg-blue-500 mr-3"></span>
                  Choose a haircut that complements your face shape
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 mt-2 rounded-full bg-blue-500 mr-3"></span>
                  Visit a barber regularly for maintenance
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 mt-2 rounded-full bg-blue-500 mr-3"></span>
                  Use quality hair products for natural styling
                </li>
              </ul>
            </div>
          </div>

          {/* Style Section */}
          <div className="bg-white rounded-2xl shadow-sm hover:shadow-md transition-shadow overflow-hidden">
            <img 
              src="https://images.unsplash.com/photo-1490578474895-699cd4e2cf59?auto=format&fit=crop&w=2071&q=80"
              alt="Well-dressed man"
              className="w-full h-48 object-cover"
            />
            <div className="p-8">
              <div className="flex items-center mb-6">
                <ShoppingBag className="w-8 h-8 text-blue-500 mr-4" />
                <h2 className="text-2xl font-bold">Dress Well and Smell Great</h2>
              </div>
              <ul className="space-y-4 text-gray-600">
                <li className="flex items-start">
                  <span className="w-2 h-2 mt-2 rounded-full bg-blue-500 mr-3"></span>
                  Wear well-fitted clothes that match your style
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 mt-2 rounded-full bg-blue-500 mr-3"></span>
                  Choose neutral colors for timeless appeal
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 mt-2 rounded-full bg-blue-500 mr-3"></span>
                  Keep your shoes clean and stylish
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 mt-2 rounded-full bg-blue-500 mr-3"></span>
                  Use a mild yet captivating fragrance
                </li>
              </ul>
            </div>
          </div>

          {/* Physique Section */}
          <div className="bg-white rounded-2xl shadow-sm hover:shadow-md transition-shadow overflow-hidden">
            <img 
              src="https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?auto=format&fit=crop&w=2070&q=80"
              alt="Man working out"
              className="w-full h-48 object-cover"
            />
            <div className="p-8">
              <div className="flex items-center mb-6">
                <Dumbbell className="w-8 h-8 text-blue-500 mr-4" />
                <h2 className="text-2xl font-bold">Build a Strong Physique</h2>
              </div>
              <ul className="space-y-4 text-gray-600">
                <li className="flex items-start">
                  <span className="w-2 h-2 mt-2 rounded-full bg-blue-500 mr-3"></span>
                  Exercise regularly with strength training and cardio
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 mt-2 rounded-full bg-blue-500 mr-3"></span>
                  Maintain a healthy, nutrient-rich diet
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 mt-2 rounded-full bg-blue-500 mr-3"></span>
                  Get adequate sleep for body recovery
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* Confidence Section */}
        <div className="mt-16 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl text-white p-12">
          <div className="max-w-3xl mx-auto text-center">
            <img 
              src="https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=987&q=80"
              alt="Confident professional"
              className="w-32 h-32 object-cover rounded-full mx-auto mb-8 border-4 border-white/30"
            />
            <h2 className="text-3xl font-bold mb-6">Develop Confidence and Charisma</h2>
            <div className="grid md:grid-cols-2 gap-8">
              <div className="space-y-4">
                <p className="flex items-center justify-center">
                  <Heart className="w-5 h-5 mr-2" />
                  Maintain good posture
                </p>
                <p className="flex items-center justify-center">
                  <Heart className="w-5 h-5 mr-2" />
                  Speak with confidence
                </p>
              </div>
              <div className="space-y-4">
                <p className="flex items-center justify-center">
                  <Heart className="w-5 h-5 mr-2" />
                  Make eye contact
                </p>
                <p className="flex items-center justify-center">
                  <Heart className="w-5 h-5 mr-2" />
                  Smile genuinely
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Conclusion */}
        <div className="mt-16 text-center max-w-2xl mx-auto">
          <h2 className="text-2xl font-bold mb-4">Embrace Your Best Self</h2>
          <p className="text-gray-600">
            Remember, becoming attractive and handsome is all about self-care, grooming, and confidence. 
            When you feel good about yourself, it naturally reflects in your appearance.
          </p>
        </div>
      </div>
    </div>
  );
}

export default App;